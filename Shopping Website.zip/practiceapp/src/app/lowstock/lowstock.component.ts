import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lowstock',
  templateUrl: './lowstock.component.html',
  styleUrls: ['./lowstock.component.css']
})
export class LowstockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
